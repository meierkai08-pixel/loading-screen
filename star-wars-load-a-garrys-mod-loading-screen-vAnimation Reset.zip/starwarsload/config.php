<?php

//General
$APIKey = ""; // Go get your API here: http://steamcommunity.com/dev/apikey

$load_name ="Star Wars Load"; // For your Browser Name
$community_name ="Star Wars Load"; // Your community/server name. The one in the middle
$community_url = "www.starwarsload.com"; // Url for your users to know where to go
$intro = TRUE; // If you want to turn this off, type FALSE instead
// Introduction
$tagline = " A long time ago, in a server far,<br> far away...."; // The intro text in the beginning of the animation
// Above Server Name
$sub_title_1 = "Welcome to the force"; // Above your server name
// Under Server Name
$sub_title_2 = "read the rules to learn the ways of the force"; // Below your server name

//Bottom Part
$left_bottom_title = "About Us";
$left_bottom_sub_title = "$community_url for more info";
$right_bottom_title = "Our Server";
$right_bottom_sub_title = "General information about the server";

$left_bottom_text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris laoreet tortor a varius efficitur. Aenean sodales ut eros a feugiat. Sed imperdiet tincidunt massa ut ultricies. In accumsan velit nec libero ultrices pulvinar. Praesent blandit, ante eget tristique consectetur, est erat pretium tortor, ac dignissim mauris tellus non nunc. Vivamus tincidunt justo id tristique tempus. Sed ultrices tincidunt tincidunt. ";

?>